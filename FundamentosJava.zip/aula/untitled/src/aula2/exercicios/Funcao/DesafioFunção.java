package aula2.exercicios.Funcao;

public class DesafioFunção {
}
