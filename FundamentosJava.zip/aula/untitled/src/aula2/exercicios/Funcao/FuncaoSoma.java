package aula2.exercicios.Funcao;

public class FuncaoSoma {



        public static int somar(int a, int b) {
            return a + b;
        }

        public static void main(String[] args) {
            int resultado = somar(5, 3);
            System.out.println("A soma é: " + resultado);
        }
    }







