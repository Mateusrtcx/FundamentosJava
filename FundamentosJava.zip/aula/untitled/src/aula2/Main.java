package aula2;

import java.util.Scanner;

public class Main {


    static void main(String[] args) {










    }







}







